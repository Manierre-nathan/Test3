import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class DuplicateCounter {

    private Map<String, Integer> wordCounter;


    public void count(String dataFile){

    }

    public void write(String outputFile){

    }




}
