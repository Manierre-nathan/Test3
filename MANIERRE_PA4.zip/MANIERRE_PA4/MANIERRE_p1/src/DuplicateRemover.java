import java.util.Set;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;



public class DuplicateRemover {

    // Use a Set of Strings to eliminate duplicate words from dataFile
    private Set<String> uniqueWords;         // put the unique words in here

    public void remove(String dataFile) throws IOException {     // dataFile represents path to text file

        String wordToAdd;


//        dataFile = "MANIERRE_PA4/MANIERRE_p1/src/problem1.txt";     // REMOVE THIS WHEN DONE HERE *********


        try {

//            File inputFile = new File(dataFile);

            Scanner scInput = new Scanner(dataFile);

            // use scanner to add words to unique word ...
            while (scInput.hasNext()) {
                wordToAdd = scInput.next();
                uniqueWords.add(wordToAdd);
            }

            // clean up all resources allocated during method execution
            scInput.close();
        } catch (IOException e) {
            System.out.println("Exception: File IO.");
        }


    }


    public void write(String outputFile) {  // outputFile represents path to text file
        // terminate the program and alert the user when an exceptional IO event occurs

        FileWriter fWriter;

        File output = new File(outputFile);

        try {
            fWriter = new FileWriter(output, true);

            Iterator i = uniqueWords.iterator();
            while (i.hasNext()) {
                String strWrite = (String) i.next();
                fWriter.write(strWrite + "\n");
            }

            fWriter.close();
            System.out.println("The new unique words have been written to file");
        } catch (IOException e) {
            System.out.println("Exception: File IO.");
        }

    }
}
